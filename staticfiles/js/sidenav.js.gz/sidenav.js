function openSide(){
    document.getElementById("sidenav").style.right = "0"
}
function closeSide(){
    document.getElementById("sidenav").style.right = "-500px"
}
